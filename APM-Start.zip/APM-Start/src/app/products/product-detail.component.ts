import { Component, OnInit } from '@angular/core';
import { IProduct, Product } from './product';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  /*
  We use selector if we want to use a component inside other components, here we will use routing and hence
  won't require the usage of a selector. Hence we won't nest the view of this component.
  */
  //selector: 'pm-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  pageTitle : string = 'Product Detail';
  product : Product;
  constructor(private route : ActivatedRoute, private router : Router) {   }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this.pageTitle += `:${id}`;
    console.log(this.pageTitle);
    this.product = {
      
        productid: +id,
        "productName": "Leaf Rake",
        "productCode": "GDN-0011",
        "releaseDate": "March 19, 2016",
        "description": "Leaf rake with 48-inch wooden handle.",
        "price": 19.95,
        "starRating": 3.2,
        "imageUrl": "https://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png"
      
    }

  }//ngOnInit

  onBack() : void {
    this.router.navigate(['/products']);
  }

}
