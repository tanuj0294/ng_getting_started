import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MyAppComponent } from './app.component';
import { UiModule } from './ui/ui.module';
import { ProductListComponent } from './products/product-list.component'
import { FormsModule } from '@angular/forms';
import { ConvertToSpacesPipe } from './shared/convert-to-spaces.pipe';
import { StarComponent } from './shared/star.component';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
import { WelcomeComponent } from './home/welcome.component';
import { RouterModule } from '@angular/router';
import { ProductDetailGuard } from './products/product-detail.guard';

@NgModule({
  declarations: [MyAppComponent, ProductListComponent, ConvertToSpacesPipe, StarComponent, ProductDetailComponent, WelcomeComponent],
  imports: [BrowserModule, UiModule, FormsModule, HttpClientModule, RouterModule.forRoot([
    { path: 'products', component: ProductListComponent },
    //canActivate accepts [ ] hence we have to provide the square brackets
    { path: 'products/:id', component: ProductDetailComponent, canActivate: [ProductDetailGuard] },
    { path: 'welcome', component: WelcomeComponent },
    { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  ])],
  /*this here should only import modules
  I tried importing ProductListComponent and it was resulting in the error :
  Unexpected directive 'ProductListComponent' imported by the module 'AppModule'. Please add a @NgModule annotation. */
  bootstrap: [MyAppComponent]
})
export class AppModule { }
